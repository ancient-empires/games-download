(function (win) {

	"use strict";
	/*global console, alert, window, document */
	/*global */

	win.APP.BB.Unit.GalamarModel =  win.APP.BB.Unit.BaseUnitModel.extend({

		defaults: win.APP.unitMaster.list.galamar

	});

}(window));